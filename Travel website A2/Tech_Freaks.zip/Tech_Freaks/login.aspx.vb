﻿
Imports System.Data.OleDb

Partial Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Check if user is already logged in
        If User.Identity.IsAuthenticated Then
            Response.Redirect("Home.aspx")
        End If
    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        ' Get the username and password from the form
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        ' Create an OleDbConnection object to connect to the database
        Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Database.mdb;Persist Security Info=True"

        Dim conn As New OleDbConnection(connectionString)

        ' Create an OleDbCommand object to execute the SELECT statement
        Dim query As String = "SELECT * FROM Login WHERE UserID=@Username AND Password=@Password"
        Dim cmd As New OleDbCommand(query, conn)
        cmd.Parameters.AddWithValue("@Username", username)
        cmd.Parameters.AddWithValue("@Password", password)

        ' Open the database connection and execute the SELECT statement
        conn.Open()
        Dim reader As OleDbDataReader = cmd.ExecuteReader()
        'Check if the SELECT statement returned a row
        If reader.HasRows Then
            ' The user is authenticated
            reader.Read()
            Response.Redirect("Home.aspx")

        Else
            ' The user is not authenticated
            lblMessage.Text = "Invalid username or password."
        End If

        ' Close the database connection and the OleDbDataReader object
        reader.Close()

        conn.Close()

    End Sub
End Class