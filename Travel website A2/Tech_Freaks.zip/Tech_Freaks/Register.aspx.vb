﻿Imports System.Data.OleDb
Imports System.IO

Partial Class Register
    Inherits System.Web.UI.Page

    Protected Sub btnRegister_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegister.Click
        ' Create a connection string to your database
        Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Database.mdb;Persist Security Info=True"

        ' Create an OleDbConnection
        Using connection As New OleDbConnection(connectionString)
            ' Define the SQL query to insert the user data into the table
            Dim query As String = "INSERT INTO [Login] ([UserID], [Password],[Email],[FirstName],[LastName],[Gender]) VALUES (?,?,?,?,?,?)"

            ' Create an OleDbCommand with the query and connection
            Using command As New OleDbCommand(query, connection)
                ' Add parameters and their values
                command.Parameters.Add("@p1", OleDbType.VarChar).Value = txtUsername.Text
                command.Parameters.Add("@p2", OleDbType.VarChar).Value = txtPassword.Text
                command.Parameters.Add("@p2", OleDbType.VarChar).Value = txtEmail.Text
                command.Parameters.Add("@p2", OleDbType.VarChar).Value = txtFName.Text
                command.Parameters.Add("@p2", OleDbType.VarChar).Value = txtLName.Text
                command.Parameters.Add("@p2", OleDbType.VarChar).Value = ddlProgram.Text
                ' Open the connection
                connection.Open()

                ' Execute the command
                command.ExecuteNonQuery()
            End Using
        End Using

        ' Reset the form fields after inserting the data
        txtUsername.Text = ""
        txtPassword.Text = ""

        ' Display the registration success message on the same page
        lblMessage.Text = "Registration successful! Thank you for registering."
    End Sub
End Class
