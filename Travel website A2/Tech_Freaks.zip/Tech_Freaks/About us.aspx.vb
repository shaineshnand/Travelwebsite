﻿
Partial Class About_us
    Inherits System.Web.UI.Page

End Class
