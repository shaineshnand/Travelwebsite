﻿
Partial Class developer_4
    Inherits System.Web.UI.Page

End Class
