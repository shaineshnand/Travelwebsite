﻿
Partial Class developer_3
    Inherits System.Web.UI.Page

End Class
