﻿
Partial Class developer_2
    Inherits System.Web.UI.Page

End Class
