﻿Imports System.Data.OleDb

Partial Class bookings_Nadi
    Inherits System.Web.UI.Page

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Database.mdb"

        Dim query As String = "INSERT INTO nadi_booking (FullName, Email, TravelDate, TransportType) VALUES (@FullName, @Email, @TravelDate, @TransportType)"

        Using connection As New OleDbConnection(connectionString)
            Using command As New OleDbCommand(query, connection)
                command.Parameters.AddWithValue("@FullName", TextBox2.Text.Trim())
                command.Parameters.AddWithValue("@Email", TextBox3.Text.Trim())
                command.Parameters.AddWithValue("@TravelDate", TextBox4.Text.Trim())
                command.Parameters.AddWithValue("@TransportType", DropDownList1.SelectedValue)

                connection.Open()

                Try
                    command.ExecuteNonQuery()
                    TextBox2.Text = ""
                    TextBox3.Text = ""
                    TextBox4.Text = ""
                    DropDownList1.SelectedIndex = 0

                    ' Display success message
                    Label1.Text = "Booking successful! You will receive a confirmation letter soon in your Email... Travel safe with Easy Travel."
                Catch ex As Exception
                    Label1.Text = "An error occurred while processing the booking: " & ex.Message
                End Try
            End Using
        End Using
    End Sub
End Class
