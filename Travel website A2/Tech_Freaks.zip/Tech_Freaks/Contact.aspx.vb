﻿Imports System.Data.OleDb

Partial Class contact2
    Inherits System.Web.UI.Page

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        ' Create a connection string to your database
        Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Database.mdb;Persist Security Info=True"

        ' Create an OleDbConnection
        Using connection As New OleDbConnection(connectionString)
            ' Define the SQL query to insert the data into the table
            Dim query As String = "INSERT INTO [Contact] ([Name], [Email], [Subject], [Message]) VALUES (?, ?, ?, ?)"

            ' Create an OleDbCommand with the query and connection
            Using command As New OleDbCommand(query, connection)
                ' Add parameters and their values
                command.Parameters.AddWithValue("@p1", TextBox3.Text.Trim())
                command.Parameters.AddWithValue("@p2", TextBox4.Text.Trim())
                command.Parameters.AddWithValue("@p3", TextBox5.Text.Trim())
                command.Parameters.AddWithValue("@p4", TextBox6.Text.Trim())

                ' Open the connection
                connection.Open()

                ' Execute the command
                Try
                    command.ExecuteNonQuery()
                    ' Reset the textboxes after successful insertion
                    TextBox3.Text = ""
                    TextBox4.Text = ""
                    TextBox5.Text = ""
                    TextBox6.Text = ""
                    ' Display a thank you message
                    Label1.Text = "Thank you for your message!"
                Catch ex As OleDbException
                    ' Handle the exception and display an error message
                    Label1.Text = "An error occurred while submitting the form: " & ex.Message
                End Try
            End Using
        End Using
    End Sub
End Class