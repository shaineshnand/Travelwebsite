﻿
Partial Class Destination
    Inherits System.Web.UI.Page

End Class
