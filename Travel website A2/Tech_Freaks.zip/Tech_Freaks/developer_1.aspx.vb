﻿
Partial Class D1aspx
    Inherits System.Web.UI.Page

End Class
